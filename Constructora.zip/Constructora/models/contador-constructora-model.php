<?php
// Implementación de la base de datos
require('../config/database.php');

// Creación de la clase para este archivo PHP
class Contador{
    //Variable que almacenara informacion de la conexion con la base de datos.
    private $connect;

    public function __construct()
    {
        $connectionObj = new Connection();
        $this->connect = $connectionObj->getConn();
    }

    //Sentencia para traer todos los datos de la tabla usuarios pendientes
    public function showUser() {
        $sqlshowUser = "SELECT * FROM usuarios";
        $executeshowUser = $this->connect->query($sqlshowUser);

        $users = array();
        while($fila = $executeshowUser->fetch_assoc()) {
            $users[] = $fila;
        }

        return $users;
    }

    //Sentencia para traer todos los datos de la tabla aceptado
    public function showAccept() {
        $sqlshowUserAcept = "SELECT * FROM aceptados";
        $executeshowUserAcept = $this->connect->query($sqlshowUserAcept);

        $usersAcept = array();
        while($fila = $executeshowUserAcept->fetch_assoc()) {
            $usersAcept[] = $fila;
        }

        return $usersAcept;
    }

    //Funcion para aceptar usuarios nuevos
    function moverDatosDePendientesAAceptadas($id_u){
        //Mover datos de pendientes a aceptadas
        $insertUser = "INSERT INTO aceptados SELECT * FROM usuarios WHERE id = $id_u";
        if ($this->connect->query($insertUser) === TRUE) {
            //Borrar solicitud de pemdientes
            $deletePendientes = "DELETE FROM usuarios WHERE id = $id_u";
            if ($this->connect->query($deletePendientes) === TRUE) {
                return true;
            }
        }
    }

    //Funcion para borra usuarios nuevos
    public function borrarUsuarios($id){
        $deleteUsuarios = "DELETE FROM usuarios WHERE id = $id";
        return $this->connect->query($deleteUsuarios);
    }
}