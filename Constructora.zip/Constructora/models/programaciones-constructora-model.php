<?php
// Implementación de la base de datos
require('../config/database.php');

// Creación de la clase para este archivo PHP
class Programaciones{
    //Variable que almacenara informacion de la conexion con la base de datos.
    private $connect;

    public function __construct()
    {
        $connectionObj = new Connection();
        $this->connect = $connectionObj->getConn();
    }

    //Funcion para obtener los datos de la tabla pedidos en proceso
    public function programaciones() {
        $sqlpedidos_Programaciones = "SELECT * FROM programaciones";
        $execute_programaciones = $this->connect->query($sqlpedidos_Programaciones);

        $programaciones = array();
        while($fila = $execute_programaciones->fetch_assoc()) {
            $programaciones[] = $fila;
        }

        return $programaciones;
    }
}