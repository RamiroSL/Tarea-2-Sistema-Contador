<?php
// Implementación de la base de datos
require('../config/database.php');

// Creación de la clase para este archivo PHP
class Pedidos_en_Proceso{
    //Variable que almacenara informacion de la conexion con la base de datos.
    private $connect;

    public function __construct()
    {
        $connectionObj = new Connection();
        $this->connect = $connectionObj->getConn();
    }

    //Funcion para obtener los datos de la tabla pedidos en proceso
    public function pedidos_en_Proceso() {
        $sqlpedidos_Proceso = "SELECT * FROM pedidos_en_proceso";
        $execute_pedidos_Proceso = $this->connect->query($sqlpedidos_Proceso);

        $pedidos = array();
        while($fila_P = $execute_pedidos_Proceso->fetch_assoc()) {
            $pedidos[] = $fila_P;
        }

        return $pedidos;
    }

    //Funcion para obtener los datos de la tabla pedidos en proceso 2
    public function pedidos_en_Proceso2() {
        $sqlpedidos_Proceso2 = "SELECT * FROM pedidos_en_proceso2";
        $execute_pedidos_Proceso2 = $this->connect->query($sqlpedidos_Proceso2);

        $pedidos2 = array();
        while($fila_P2 = $execute_pedidos_Proceso2->fetch_assoc()) {
            $pedidos2[] = $fila_P2;
        }

        return $pedidos2;
    }
}