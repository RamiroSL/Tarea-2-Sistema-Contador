<?php

require('../config/database.php');

class Perfil{
    //Variable que almacenara informacion de la conexion con la base de datos.
    private $connect;

    public function __construct()
    {
        $connectionObj = new Connection();
        $this->connect = $connectionObj->getConn();
    }

    //Funcion para extraer informacion del usuario
    public function getInformacion($rfc){
        $informacion_User = "SELECT * FROM aceptados WHERE rfc = '$rfc'";
        $result = $this->connect->query($informacion_User);

        if ($result->num_rows === 1) {
            $datos = $result->fetch_assoc();
            return $datos;
        }else {
            return null;
        }
    }

    //Funcion para actualizar datos del usuario
    public function updateInformacion($tipo, $rfc, $curp, $razon_social, $proveedor, $valor_bienes, $valor_servicios, $constancia_fiscal, $cumplimiento, $cta_bancaria, $direccion, $contactoVitasNombre, $contactoVitasCorreo, $contactoVitasTelefono, $contactoVitasCelular, $contactoContaNombre, $contactoContaCorreo, $contactoContaTelefono, $contactoContaCelular, $contactoCyCNombre, $contactoCyCCorreo, $contactoCyCTelefono, $contactoCyCCelular, $dias_credito, $password) {
        // Construir la consulta SQL de actualización
        $sql = "UPDATE aceptados SET 
                tipo = ?,
                curp = ?,
                razon_social = ?,
                proveedor = ?,
                valor_bienes = ?,
                valor_servicios = ?,
                constancia_fiscal = ?,
                cumplimiento = ?,
                cta_bancaria = ?,
                direccion = ?,
                contacto_vitas_nombre = ?,
                contacto_vitas_correo = ?,
                contacto_vitas_telefono = ?,
                contacto_vitas_celular = ?,
                contacto_conta_nombre = ?,
                contacto_conta_correo = ?,
                contacto_conta_telefono = ?,
                contacto_conta_celular = ?,
                contacto_cyc_nombre = ?,
                contacto_cyc_correo = ?,
                contacto_cyc_telefono = ?,
                contacto_cyc_celular = ?,
                dias_credito = ?,
                password = ?
                WHERE rfc = ?";
    
        // Preparar la consulta SQL
        $stmt = $this->connect->prepare($sql);
    
        // Verificar si la preparación de la consulta fue exitosa
        if ($stmt === false) {
            die("Error al preparar la consulta: " . $this->connect->error);
        }
    
        // Bind parameters
        $stmt->bind_param("sssssssssssssssssssssssss", $tipo, $curp, $razon_social, $proveedor, $valor_bienes, $valor_servicios, $constancia_fiscal, $cumplimiento, $cta_bancaria, $direccion, $contactoVitasNombre, $contactoVitasCorreo, $contactoVitasTelefono, $contactoVitasCelular, $contactoContaNombre, $contactoContaCorreo, $contactoContaTelefono, $contactoContaCelular, $contactoCyCNombre, $contactoCyCCorreo, $contactoCyCTelefono, $contactoCyCCelular, $dias_credito, $password, $rfc);
    
        // Verificar si la ejecución de la consulta fue exitosa
        if ($stmt->execute()) {
            echo"<script>alert('Los datos se actualizaron correctamente.')</script>";
            #return true; // Actualización exitosa
        } else {
            echo"<script>alert('Se produjo un error durante la actualización.')</script>";
            #return false; // Error en la actualización
        }
    }
}