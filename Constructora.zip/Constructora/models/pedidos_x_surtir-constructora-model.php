<?php
// Implementación de la base de datos
require('../config/database.php');

// Creación de la clase para este archivo PHP
class Pedidos_x_Surtir{
    //Variable que almacenara informacion de la conexion con la base de datos.
    private $connect;

    public function __construct()
    {
        $connectionObj = new Connection();
        $this->connect = $connectionObj->getConn();
    }

    //Funcion para obtener los datos de la tabla pedidos en proceso
    public function pedidos_Surtir() {
        $sqlpedidos_Surtir = "SELECT * FROM pedidos_x_surtir";
        $execute_pedidos_Surtir = $this->connect->query($sqlpedidos_Surtir);

        $pedidos_surtir = array();
        while($fila_P = $execute_pedidos_Surtir->fetch_assoc()) {
            $pedidos_surtir[] = $fila_P;
        }

        return $pedidos_surtir;
    }

    //Funcion para tabla 2
    public function pedidos_Surtir2() {
        $sqlpedidos_surtir = "SELECT * FROM pedidos_x_surtir2";
        $execute_pedidos_surtir = $this->connect->query($sqlpedidos_surtir);

        $pedidos_s = array();
        while($fila = $execute_pedidos_surtir->fetch_assoc()) {
            $pedidos_s[] = $fila;
        }

        return $pedidos_s;
    }
}