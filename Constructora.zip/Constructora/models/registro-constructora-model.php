<?php

require('../config/database.php');

class Registro{
    //Variable que almacenara informacion de la conexion con la base de datos.
    private $connect;

    public function __construct()
    {
        $connectionObj = new Connection();
        $this->connect = $connectionObj->getConn();
    }

    //Funcion para registrar usuarios
    public function registerUser($tipo, $rfc, $curp, $razon_social, $proveedor, $valor_bienes, $valor_servicios, $constancia_fiscal, $cumplimiento, $cta_bancaria, $direccion, $contactoVitasNombre, $contactoVitasCorreo, $contactoVitasTelefono, $contactoVitasCelular, $contactoContaNombre, $contactoContaCorreo, $contactoContaTelefono, $contactoContaCelular, $contactoCyCNombre, $contactoCyCCorreo, $contactoCyCTelefono, $contactoCyCCelular, $dias_credito, $password) {
        // Sentencia SQL para insertar el usuario en la base de datos
        $sql = "INSERT INTO usuarios (tipo, rfc, curp, razon_social, proveedor, valor_bienes, valor_servicios, constancia_fiscal, cumplimiento, cta_bancaria, direccion, contacto_vitas_nombre, contacto_vitas_correo, contacto_vitas_telefono, contacto_vitas_celular, contacto_conta_nombre, contacto_conta_correo, contacto_conta_telefono, contacto_conta_celular, contacto_cyc_nombre, contacto_cyc_correo, contacto_cyc_telefono, contacto_cyc_celular, dias_credito, password)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $stmt = $this->connect->prepare($sql);

        if ($stmt === false) {
            die("Error al preparar la consulta: " . $this->connect->error);
        }

        $stmt->bind_param("sssssssssssssssssssssssss", $tipo, $rfc, $curp, $razon_social, $proveedor, $valor_bienes, $valor_servicios, $constancia_fiscal, $cumplimiento, $cta_bancaria, $direccion, $contactoVitasNombre, $contactoVitasCorreo, $contactoVitasTelefono, $contactoVitasCelular, $contactoContaNombre, $contactoContaCorreo, $contactoContaTelefono, $contactoContaCelular, $contactoCyCNombre, $contactoCyCCorreo, $contactoCyCTelefono, $contactoCyCCelular, $dias_credito, $password);

        if ($stmt->execute()) {
            // Éxito
            return true;
        } else {
            // Error
            return false;
        }
    }
    
}