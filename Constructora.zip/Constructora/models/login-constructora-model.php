<?php
// Implementación de la base de datos
require('../config/database.php');

// Creación de la clase para este archivo PHP
class Login {
    //Variable que almacenara informacion de la conexion con la base de datos.
    private $connect;

    public function __construct()
    {
        $connectionObj = new Connection();
        $this->connect = $connectionObj->getConn();
    }

    //Funcion para validar usuario
    public function verificaUsuarios($rfc, $password) {
        // Declaración del query para buscar al usuario en la tabla 'aceptados'
        $queryAceptados = "SELECT rfc, password, id FROM aceptados WHERE rfc = ? AND password = ?";
        
        // Ejecuta la consulta SQL para buscar al usuario en la tabla 'aceptados'
        $stmtAceptados = $this->connect->prepare($queryAceptados);
        $stmtAceptados->bind_param("ss", $rfc, $password);
        $stmtAceptados->execute();
        $resultAceptados = $stmtAceptados->get_result();
    
        if ($resultAceptados->num_rows > 0) {
            // El usuario se encuentra en la tabla 'aceptados', inicia sesión
            $_SESSION['rfc'] = $rfc;
            echo "<script>location.href='./Home/'</script>";
        } else {
            // El usuario no se encuentra en la tabla aceptados no está aceptado en el sistema y muestra una alerta
            echo "<script>alert('El usuario aun no está aceptado en el sistema')</script>";
            echo "<script>location.href='./Login'</script>";
        }
    }
}