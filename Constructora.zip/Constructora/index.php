<?php
session_start();

if (isset($_SESSION['rfc'])) {
    echo "<script>location.href='./Home/'</script>";
} else {
    echo "<script>location.href='./Login'</script>";
}