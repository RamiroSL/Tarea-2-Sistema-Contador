$(document).ready(function () {
    $("#proveedor").change(function () {
        var selectedOption = $(this).children("option:selected").val();
        if (selectedOption === "Bienes") {
            $("#valor_bienes").prop("disabled", false);
            $("#valor_servicios").prop("disabled", true);
        } else if (selectedOption === "Servicios") {
            $("#valor_bienes").prop("disabled", true);
            $("#valor_servicios").prop("disabled", false);
        } else {
            $("#valor_bienes").prop("disabled", true);
            $("#valor_servicios").prop("disabled", true);
        }
    });
});

//Validacion del curp
function validarCURP(input) {
    // Expresión regular para verificar el formato de CURP
    const curpRegex = /^[A-Z]{4}[0-9]{6}[H,M][A-Z]{5}[A-Z0-9]{2}$/;

    if (curpRegex.test(input.value)) {
        input.classList.remove("is-invalid");
        input.classList.add("is-valid");
    } else {
        input.classList.remove("is-valid");
        input.classList.add("is-invalid");
    }
}

//Validar Rfc dependiendo si es persona moral o fisica
function validarRFC(input) {
    const tipoRFC = document.getElementById("tipo").value;
    const rfc = input.value;

    let rfcRegex;

    if (tipoRFC === 'Fisica') {
        // RFC de persona física
        rfcRegex = /^[A-Z]{4}[0-9]{6}[A-Z0-9]{3}$/;
    } else if (tipoRFC === 'Moral') {
        // RFC de persona moral
        rfcRegex = /^[A-Z]{3}[0-9]{6}[A-Z0-9]{3}$/;
    } else {
        // Tipo no seleccionado, no hacemos ninguna validación
        input.classList.remove("is-valid");
        input.classList.remove("is-invalid");
        return;
    }

    if (rfcRegex.test(rfc)) {
        input.classList.remove("is-invalid");
        input.classList.add("is-valid");
    } else {
        input.classList.remove("is-valid");
        input.classList.add("is-invalid");
    }
}

//Validacion de Pdf
function validarArchivo(input) {
    const fileInput = input;
    const selectedFile = fileInput.files[0];

    // Expresión regular para verificar la extensión del archivo
    const pdfRegex = /\.(pdf)$/i;

    if (selectedFile && pdfRegex.test(selectedFile.name)) {
        // El archivo seleccionado es un PDF, puedes continuar con el proceso.
        // Aquí puedes agregar más lógica, como la carga del archivo o la validación adicional.
        input.classList.remove("is-invalid");
        input.classList.add("is-valid");
    } else {
        // Muestra el mensaje de error

        input.classList.remove("is-valid");
        input.classList.add("is-invalid");
        fileInput.value = ""; // Borra la selección del archivo
    }
}

//Validacion de los correos
function validarCorreo(input) {
    const correoInput = input;
    const correo = correoInput.value;

    // Expresión regular para validar una dirección de correo electrónico
    const correoRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;

    if (correoRegex.test(correo)) {
        // La dirección de correo es válida
        correoInput.classList.remove("is-invalid");
        correoInput.classList.add("is-valid");
    } else {
        // La dirección de correo no es válida
        correoInput.classList.remove("is-valid");
        correoInput.classList.add("is-invalid");
    }
}

//Validar los numeros de telefono
function validarTelefono(input) {
    const telefonoInput = input;
    const telefono = telefonoInput.value;

    // Expresión regular para validar un número de teléfono (10 dígitos)
    const telefonoRegex = /^\d{10}$/;

    if (telefonoRegex.test(telefono)) {
        // El número de teléfono es válido
        telefonoInput.classList.remove("is-invalid");
        telefonoInput.classList.add("is-valid");
    } else {
        // El número de teléfono no es válido
        telefonoInput.classList.remove("is-valid");
        telefonoInput.classList.add("is-invalid");
    }
}

//Validar numeros de celular
function validarCelular(input) {
    const celularInput = input;
    const celular = celularInput.value;

    // Expresión regular para validar un número de celular (10 dígitos)
    const celularRegex = /^\d{10}$/;

    if (celularRegex.test(celular)) {
        // El número de celular es válido
        celularInput.classList.remove("is-invalid");
        celularInput.classList.add("is-valid");

    } else {
        // El número de celular no es válido
        celularInput.classList.remove("is-valid");
        celularInput.classList.add("is-invalid");
    }
}

//Validar que el campo nombre no este vacio
function validarNombre(input) {
    const nombreInput = input;
    const nombre = nombreInput.value;

    if (nombre.trim() === "") {
        // El campo de nombre está vacío
        nombreInput.classList.remove("is-valid");
        nombreInput.classList.add("is-invalid");
    } else {
        // El campo de nombre no está vacío
        nombreInput.classList.remove("is-invalid");
        nombreInput.classList.add("is-valid");
    }
}