// Función para validar el reCAPTCHA
function validarRecaptcha() {
    var response = grecaptcha.getResponse();
    if (response.length === 0) {
        alert("Por favor, completa el reCAPTCHA.");
        return false;
    }
    return true;
}

// Evento de envío del formulario
document.getElementById("mi-formulario").addEventListener("submit", function (event) {
    if (!validarRecaptcha()) {
        event.preventDefault(); // Evita que se envíe el formulario si el reCAPTCHA no está completo
    }
});