<?php
//error_reporting(0); //Errores controlados

class Connection {
    //Declaracion del host de las credenciiales
    private $host = "localhost";
    private $username = "root";
    private $password = "";
    private $dbname = "constructora";

    //Declaracion de la variiable que llevara la conexion
    private $con;

    //Constructor de la clase Connection
    public function __construct(){
        //Se establece conexion con la base de datos.
        $this->con = new mysqli($this->host, $this->username, $this->password, $this->dbname);
        //Se valida que la conexion sea aprovada
        if ($this->con->connect_error) {
            //En dado caso de que no se redireccionara a la pantalla de error.
            echo "<script>location.href='../Error-Connection/'</script>";
        }
    }

    public function getConn(){
        //Se declara la funciion "GetCon" para el encapsulamimiento de datos
        return $this->con;
    }
}