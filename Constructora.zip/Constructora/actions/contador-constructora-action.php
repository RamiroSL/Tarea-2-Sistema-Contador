<?php
session_start();

require('../models/contador-constructora-model.php');

$usuario = new Contador();

// Verificar si el usuario ha iniciado sesión

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Comprobar si se hizo clic en el botón "Aceptar"
        if (isset($_POST['aceptar'])) {
            $id_u = $_GET['id'];
            
            // Mover datos de pendientes a aceptadas
            $aceptar_usuarios = $usuario->moverDatosDePendientesAAceptadas($id_u);

        } elseif (isset($_POST['delete'])) {
            $id_u = $_GET['id'];
                    
            $deleteUsers = $usuario->borrarUsuarios($id_u);
        }

        // Incluir la vista de Home de Contador después de cualquiera de las operaciones (Aceptar o Borrar)
        header("Location: ../Home/");
}else {
    // Si no existe una sesión activa o el valor de 'email' no está establecido, redirecciona al usuario a la página principal.
    echo "<script>location.href='../Login'</script>";
}