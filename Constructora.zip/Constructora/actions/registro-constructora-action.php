<?php
session_start();

require('../models/registro-constructora-model.php');

$registroUser = new Registro();

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Recuperar los datos del formulario
    $tipo = isset($_POST["tipo"]) ? $_POST["tipo"] : "";
    $rfc = isset($_POST["rfc"]) ? strtoupper($_POST["rfc"]) : "";
    $curp = isset($_POST["curp"]) ? strtoupper($_POST["curp"]) : "";

    $razon_social =  isset($_FILES["razon_social"]["name"]) ? $_FILES["razon_social"]["name"] : "";

    $proveedor = isset($_POST["proveedor"]) ? $_POST["proveedor"] : "";
    $valor_bienes = isset($_POST["valor_bienes"]) ? $_POST["valor_bienes"] : "";
    $valor_servicios = isset($_POST["valor_servicios"]) ? $_POST["valor_servicios"] : "";

    $constancia_fiscal = isset($_FILES["constancia_fiscal"]["name"]) ? $_FILES["constancia_fiscal"]["name"] : "";

    $cumplimiento = isset($_FILES["cumplimiento"]["name"]) ? $_FILES["cumplimiento"]["name"] : "";
    $cta_bancaria = isset($_FILES["cta_bancaria"]["name"]) ? $_FILES["cta_bancaria"]["name"] : "";

    $direccion = isset($_POST["direccion"]) ? $_POST["direccion"] : "";
    $contactoVitasNombre = isset($_POST["contacto_vitas_nombre"]) ? $_POST["contacto_vitas_nombre"] : "";
    $contactoVitasCorreo = isset($_POST["contacto_vitas_correo"]) ? $_POST["contacto_vitas_correo"] : "";
    $contactoVitasTelefono = isset($_POST["contacto_vitas_telefono"]) ? $_POST["contacto_vitas_telefono"] : "";
    $contactoVitasCelular = isset($_POST["contacto_vitas_celular"]) ? $_POST["contacto_vitas_celular"] : "";
    $contactoContaNombre = isset($_POST["contacto_conta_nombre"]) ? $_POST["contacto_conta_nombre"] : "";
    $contactoContaCorreo = isset($_POST["contacto_conta_correo"]) ? $_POST["contacto_conta_correo"] : "";
    $contactoContaTelefono = isset($_POST["contacto_conta_telefono"]) ? $_POST["contacto_conta_telefono"] : "";
    $contactoContaCelular = isset($_POST["contacto_conta_celular"]) ? $_POST["contacto_conta_celular"] : "";
    $contactoCyCNombre = isset($_POST["contacto_cyc_nombre"]) ? $_POST["contacto_cyc_nombre"] : "";
    $contactoCyCCorreo = isset($_POST["contacto_cyc_correo"]) ? $_POST["contacto_cyc_correo"] : "";
    $contactoCyCTelefono = isset($_POST["contacto_cyc_telefono"]) ? $_POST["contacto_cyc_telefono"] : "";
    $contactoCyCCelular = isset($_POST["contacto_cyc_celular"]) ? $_POST["contacto_cyc_celular"] : "";
    $dias_credito = isset($_POST["dias_credito"]) ? $_POST["dias_credito"] : "";
    $password = isset($_POST["password"]) ? $_POST["password"] : "";
    
    // Manejo de archivos
    $uploadDir = "../uploads/";

    move_uploaded_file($_FILES["razon_social"]["tmp_name"], $uploadDir . $razon_social);
    move_uploaded_file($_FILES["constancia_fiscal"]["tmp_name"], $uploadDir . $constancia_fiscal);
    move_uploaded_file($_FILES["cumplimiento"]["tmp_name"], $uploadDir . $cumplimiento);
    move_uploaded_file($_FILES["cta_bancaria"]["tmp_name"], $uploadDir . $cta_bancaria);


    // Llamada a la función del modelo para registrar al usuario
    $registrar = $registroUser->registerUser($tipo, $rfc, $curp, $razon_social, $proveedor, $valor_bienes, $valor_servicios, $constancia_fiscal, $cumplimiento, $cta_bancaria, $direccion, $contactoVitasNombre, $contactoVitasCorreo, $contactoVitasTelefono, $contactoVitasCelular, $contactoContaNombre, $contactoContaCorreo, $contactoContaTelefono, $contactoContaCelular, $contactoCyCNombre, $contactoCyCCorreo, $contactoCyCTelefono, $contactoCyCCelular, $dias_credito, $password);

    // Manejo de errores y redireccionamiento
    if ($registrar) {
        // Éxito: Redirigir a la página de éxito o mostrar un mensaje
        echo "<div id='alert-container' style='
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                background-color: #ABABAB;
                color: black;
                text-align: center;
                padding: 20px;
                border-radius: 10px;
                box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.5);
                z-index: 9999;
            '>
                <p>Estimado proveedor '$rfc'</p>
                <p>Se generó la prealta de su registro, el área correspondiente ya tiene información necesaria para que puedas formar parte de la sinergia y de la familia.</p>
                <p>En cuanto nuestros especialistas validen tu documentación, te llegará un correo electrónico con las instrucciones para nuestro portal.</p>
            
                <div id='countdown' style='
                    font-size: 22px;
                    margin-top: 20px;
                    display: inline-block;
                    padding: 10px;
                    background-color: #E1E159;
                    border-radius: 50%;
                '>
                    10
                </div>
            </div>";

            echo "<script>
            var seconds = 10;
                function countdown() {
                    seconds--;
                    document.getElementById('countdown').innerHTML = seconds;
                    if (seconds <= 0) {
                    document.getElementById('alert-container').style.display = 'none'; // Ocultar la alerta al llegar a 0
                    window.location.href = '../Login'; // Redireccionar al usuario
                    }
                }
                setInterval(countdown, 1000);
            </script>";

    } else {
        // Error: Redirigir a la página de error o mostrar un mensaje
        echo "<script>location.href='./views/Error-constructora.php'</script>";
    }
}else {
    // Si no existe una sesión activa o el valor de 'email' no está establecido, redirecciona al usuario a la página principal.
    echo "<script>location.href='./Login'</script>";
}