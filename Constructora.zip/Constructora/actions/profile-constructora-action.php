<?php

session_start();

require('../models/profile-constructora-model.php');

//Obtencion de los campos del Form por el metodo post para la actualizacion del perfil
$tipo = isset($_POST["tipo"]) ? $_POST["tipo"] : "";
$rfc = isset($_POST["rfc"]) ? strtoupper($_POST["rfc"]) : "";
$curp = isset($_POST["curp"]) ? strtoupper($_POST["curp"]) : "";

$razon_social =  isset($_FILES["razon_social"]["name"]) ? $_FILES["razon_social"]["name"] : "";
$proveedor = isset($_POST["proveedor"]) ? $_POST["proveedor"] : "";
$valor_bienes = isset($_POST["valor_bienes"]) ? $_POST["valor_bienes"] : "";
$valor_servicios = isset($_POST["valor_servicios"]) ? $_POST["valor_servicios"] : "";
$constancia_fiscal = isset($_FILES["constancia_fiscal"]["name"]) ? $_FILES["constancia_fiscal"]["name"] : "";
$cumplimiento = isset($_FILES["cumplimiento"]["name"]) ? $_FILES["cumplimiento"]["name"] : "";
$cta_bancaria = isset($_FILES["cta_bancaria"]["name"]) ? $_FILES["cta_bancaria"]["name"] : "";
$direccion = isset($_POST["direccion"]) ? $_POST["direccion"] : "";

$contactoVitasNombre = isset($_POST["contacto_vitas_nombre"]) ? $_POST["contacto_vitas_nombre"] : "";
$contactoVitasCorreo = isset($_POST["contacto_vitas_correo"]) ? $_POST["contacto_vitas_correo"] : "";
$contactoVitasTelefono = isset($_POST["contacto_vitas_telefono"]) ? $_POST["contacto_vitas_telefono"] : "";
$contactoVitasCelular = isset($_POST["contacto_vitas_celular"]) ? $_POST["contacto_vitas_celular"] : "";
$contactoContaNombre = isset($_POST["contacto_conta_nombre"]) ? $_POST["contacto_conta_nombre"] : "";
$contactoContaCorreo = isset($_POST["contacto_conta_correo"]) ? $_POST["contacto_conta_correo"] : "";
$contactoContaTelefono = isset($_POST["contacto_conta_telefono"]) ? $_POST["contacto_conta_telefono"] : "";
$contactoContaCelular = isset($_POST["contacto_conta_celular"]) ? $_POST["contacto_conta_celular"] : "";
$contactoCyCNombre = isset($_POST["contacto_cyc_nombre"]) ? $_POST["contacto_cyc_nombre"] : "";
$contactoCyCCorreo = isset($_POST["contacto_cyc_correo"]) ? $_POST["contacto_cyc_correo"] : "";
$contactoCyCTelefono = isset($_POST["contacto_cyc_telefono"]) ? $_POST["contacto_cyc_telefono"] : "";
$contactoCyCCelular = isset($_POST["contacto_cyc_celular"]) ? $_POST["contacto_cyc_celular"] : "";
$dias_credito = isset($_POST["dias_credito"]) ? $_POST["dias_credito"] : "";
$password = isset($_POST["password"]) ? $_POST["password"] : "";

$uploadDir = "../uploads/";
move_uploaded_file($_FILES["razon_social"]["tmp_name"], $uploadDir . $razon_social);
move_uploaded_file($_FILES["constancia_fiscal"]["tmp_name"], $uploadDir . $constancia_fiscal);
move_uploaded_file($_FILES["cumplimiento"]["tmp_name"], $uploadDir . $cumplimiento);
move_uploaded_file($_FILES["cta_bancaria"]["tmp_name"], $uploadDir . $cta_bancaria);

//Se verifica si hay una sesion activa
if ($_SESSION['rfc']) {
    
    //Crear insatancia del objeto Perfil
    $ObjPerfil = new Perfil();

    //Llamar la funcion para actualizar los datos
    $actualizar = $ObjPerfil->updateInformacion($tipo, $rfc, $curp, $razon_social, $proveedor, $valor_bienes, $valor_servicios, $constancia_fiscal, $cumplimiento, $cta_bancaria, $direccion, $contactoVitasNombre, $contactoVitasCorreo, $contactoVitasTelefono, $contactoVitasCelular, $contactoContaNombre, $contactoContaCorreo, $contactoContaTelefono, $contactoContaCelular, $contactoCyCNombre, $contactoCyCCorreo, $contactoCyCTelefono, $contactoCyCCelular, $dias_credito, $password);

    //Redireccionar al usuario a la pagina de perfil
    echo "<script>location.href='../Profile'</script>";

}else{
    //Si no hay una sesion activa redirigir al al Login
    echo "<script>location.href='./Login'</script>";
}