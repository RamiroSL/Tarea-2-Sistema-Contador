-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 23-10-2023 a las 02:08:51
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `constructora`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `aceptados`
--

CREATE TABLE `aceptados` (
  `id` int(11) NOT NULL,
  `tipo` varchar(255) NOT NULL,
  `rfc` varchar(255) NOT NULL,
  `curp` varchar(255) NOT NULL,
  `razon_social` varchar(255) NOT NULL,
  `proveedor` varchar(255) NOT NULL,
  `valor_bienes` varchar(255) DEFAULT NULL,
  `valor_servicios` varchar(255) DEFAULT NULL,
  `constancia_fiscal` varchar(255) NOT NULL,
  `cumplimiento` varchar(255) NOT NULL,
  `cta_bancaria` varchar(255) NOT NULL,
  `direccion` varchar(255) NOT NULL,
  `contacto_vitas_nombre` varchar(255) NOT NULL,
  `contacto_vitas_correo` varchar(255) NOT NULL,
  `contacto_vitas_telefono` varchar(255) NOT NULL,
  `contacto_vitas_celular` varchar(255) NOT NULL,
  `contacto_conta_nombre` varchar(255) NOT NULL,
  `contacto_conta_correo` varchar(255) NOT NULL,
  `contacto_conta_telefono` varchar(255) NOT NULL,
  `contacto_conta_celular` varchar(255) NOT NULL,
  `contacto_cyc_nombre` varchar(255) NOT NULL,
  `contacto_cyc_correo` varchar(255) NOT NULL,
  `contacto_cyc_telefono` varchar(255) NOT NULL,
  `contacto_cyc_celular` varchar(255) NOT NULL,
  `dias_credito` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `aceptados`
--

INSERT INTO `aceptados` (`id`, `tipo`, `rfc`, `curp`, `razon_social`, `proveedor`, `valor_bienes`, `valor_servicios`, `constancia_fiscal`, `cumplimiento`, `cta_bancaria`, `direccion`, `contacto_vitas_nombre`, `contacto_vitas_correo`, `contacto_vitas_telefono`, `contacto_vitas_celular`, `contacto_conta_nombre`, `contacto_conta_correo`, `contacto_conta_telefono`, `contacto_conta_celular`, `contacto_cyc_nombre`, `contacto_cyc_correo`, `contacto_cyc_telefono`, `contacto_cyc_celular`, `dias_credito`, `password`) VALUES
(52, 'Fisica', 'LETJ021011GP7', 'LETJ021011HMCNRNA4', 'Proyecto Azure DevOps.pdf', 'Bienes', 'Prefabricados', '', 'Funcionalidad de la Aplicación del Videojuego Super Mario Bros.pdf', 'Funcionalidad de la Aplicación del Videojuego Super Mario Bros.pdf', 'Proyecto Azure DevOps.pdf', 'Emiliano Zapata', 'Jonathan A', 'jon@gmail.com', '1234567891', '5556745332', 'Ramiro S', 'ram@gmail.com', '5523456787', '5576583956', 'Gustavo M', 'gus@gmail.com', '5555555555', '5571929587', '8 Días', '123'),
(53, 'Fisica', 'LETJ021011GP0', 'LETJ021011HMCNRNA4', 'Funcionalidad de la Aplicación del Videojuego Super Mario Bros.pdf', 'Bienes', '', '', 'Funcionalidad de la Aplicación del Videojuego Super Mario Bros.pdf', 'Funcionalidad de la Aplicación del Videojuego Super Mario Bros.pdf', 'Funcionalidad de la Aplicación del Videojuego Super Mario Bros.pdf', 'Emiliano Zapata', 'Jonathan A', 'jon@gmail.com', '1234567891', '5556745332', 'Ramiro S', 'ram@gmail.com', '5523456787', '5555555555', 'Gustavo M', 'gus@gmail.com', '5555555555', '5571929587', '15 Días', 'jonathan1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos_en_proceso`
--

CREATE TABLE `pedidos_en_proceso` (
  `ID_P` int(11) NOT NULL,
  `Entrada_Al` datetime DEFAULT NULL,
  `Pedido` varchar(50) DEFAULT NULL,
  `Factura` varchar(50) DEFAULT NULL,
  `XML` blob DEFAULT NULL,
  `Estatus` varchar(20) DEFAULT NULL,
  `Observaciones` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `pedidos_en_proceso`
--

INSERT INTO `pedidos_en_proceso` (`ID_P`, `Entrada_Al`, `Pedido`, `Factura`, `XML`, `Estatus`, `Observaciones`) VALUES
(1, '2023-10-21 00:00:00', 'Proyecto A', 'Factura-001', 0x727574615f6172636869766f2e786d6c, 'En proceso', 'Observaciones del pedido'),
(2, '2023-10-22 00:00:00', 'Proyecto B', 'Factura-002', 0x727574615f6172636869766f322e786d6c, 'En proceso', 'Otras observaciones del pedido');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos_en_proceso2`
--

CREATE TABLE `pedidos_en_proceso2` (
  `ID` int(11) NOT NULL,
  `Insumo` varchar(255) DEFAULT NULL,
  `Fecha_R` date DEFAULT NULL,
  `Cantidad_P` int(11) DEFAULT NULL,
  `Cantidad_R` int(11) DEFAULT NULL,
  `Devoluciones` int(11) DEFAULT NULL,
  `Estatus` varchar(20) DEFAULT NULL,
  `Observaciones` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos_x_surtir`
--

CREATE TABLE `pedidos_x_surtir` (
  `ID_Pedido` int(11) NOT NULL,
  `Proyecto` varchar(255) DEFAULT NULL,
  `Fecha_E` date DEFAULT NULL,
  `Factura` varchar(50) DEFAULT NULL,
  `XML` varchar(50) DEFAULT NULL,
  `Estatus` varchar(20) DEFAULT NULL,
  `Observaciones` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `pedidos_x_surtir`
--

INSERT INTO `pedidos_x_surtir` (`ID_Pedido`, `Proyecto`, `Fecha_E`, `Factura`, `XML`, `Estatus`, `Observaciones`) VALUES
(1, 'Proyecto A', '2023-10-21', 'Factura-001', 'ruta_archivo_1.xml', 'En proceso', 'Observaciones del pedido 1'),
(2, 'Proyecto B', '2023-10-22', 'Factura-002', 'ruta_archivo_2.xml', 'Completado', 'Observaciones del pedido 2'),
(3, 'Proyecto C', '2023-10-23', 'Factura-003', 'ruta_archivo_3.xml', 'Pendiente', 'Observaciones del pedido 3');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos_x_surtir2`
--

CREATE TABLE `pedidos_x_surtir2` (
  `ID_P` int(11) NOT NULL,
  `Fecha_Emision` date DEFAULT NULL,
  `Fecha_Entrega` date DEFAULT NULL,
  `Programar` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `pedidos_x_surtir2`
--

INSERT INTO `pedidos_x_surtir2` (`ID_P`, `Fecha_Emision`, `Fecha_Entrega`, `Programar`) VALUES
(1, '2023-10-21', '2023-11-10', '2023-11-05'),
(2, '2023-10-22', '2023-11-15', '2023-11-08'),
(3, '2023-10-23', '2023-11-20', '2023-11-12');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `programaciones`
--

CREATE TABLE `programaciones` (
  `ID_P` int(11) NOT NULL,
  `Dias_de_Credito` int(11) DEFAULT NULL,
  `Fecha_de_Pago` date DEFAULT NULL,
  `XML` text DEFAULT NULL,
  `Estatus` varchar(255) DEFAULT NULL,
  `Observaciones` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `programaciones`
--

INSERT INTO `programaciones` (`ID_P`, `Dias_de_Credito`, `Fecha_de_Pago`, `XML`, `Estatus`, `Observaciones`) VALUES
(1, 30, '2023-11-15', '<xml_data_1>', 'Pendiente', 'Sin observaciones'),
(2, 45, '2023-12-01', '<xml_data_2>', 'Aprobado', 'Observación importante'),
(3, 60, '2024-01-10', '<xml_data_3>', 'Rechazado', 'Revisar detalles');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `tipo` varchar(255) NOT NULL,
  `rfc` varchar(255) NOT NULL,
  `curp` varchar(255) NOT NULL,
  `razon_social` varchar(255) NOT NULL,
  `proveedor` varchar(255) NOT NULL,
  `valor_bienes` varchar(255) DEFAULT NULL,
  `valor_servicios` varchar(255) DEFAULT NULL,
  `constancia_fiscal` varchar(255) NOT NULL,
  `cumplimiento` varchar(255) NOT NULL,
  `cta_bancaria` varchar(255) NOT NULL,
  `direccion` varchar(255) NOT NULL,
  `contacto_vitas_nombre` varchar(255) NOT NULL,
  `contacto_vitas_correo` varchar(255) NOT NULL,
  `contacto_vitas_telefono` varchar(255) NOT NULL,
  `contacto_vitas_celular` varchar(255) NOT NULL,
  `contacto_conta_nombre` varchar(255) NOT NULL,
  `contacto_conta_correo` varchar(255) NOT NULL,
  `contacto_conta_telefono` varchar(255) NOT NULL,
  `contacto_conta_celular` varchar(255) NOT NULL,
  `contacto_cyc_nombre` varchar(255) NOT NULL,
  `contacto_cyc_correo` varchar(255) NOT NULL,
  `contacto_cyc_telefono` varchar(255) NOT NULL,
  `contacto_cyc_celular` varchar(255) NOT NULL,
  `dias_credito` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `tipo`, `rfc`, `curp`, `razon_social`, `proveedor`, `valor_bienes`, `valor_servicios`, `constancia_fiscal`, `cumplimiento`, `cta_bancaria`, `direccion`, `contacto_vitas_nombre`, `contacto_vitas_correo`, `contacto_vitas_telefono`, `contacto_vitas_celular`, `contacto_conta_nombre`, `contacto_conta_correo`, `contacto_conta_telefono`, `contacto_conta_celular`, `contacto_cyc_nombre`, `contacto_cyc_correo`, `contacto_cyc_telefono`, `contacto_cyc_celular`, `dias_credito`, `password`) VALUES
(14, 'Moral', 'admin', 'admin', 'Codificación Segura.pdf', 'Bienes', 'Aditivos', '', 'Codificación Segura.pdf', 'Codificación Segura.pdf', 'Codificación Segura.pdf', 'Emiliano', 'a', 'jon@gmail.com', '5555555555', '5555555555', 'b', 'jon@gmail.com', '5555555555', '5555555555', 'c', 'jon@gmail.com', '5555555555', '5555555555', '30 Días', 'root');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `aceptados`
--
ALTER TABLE `aceptados`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `pedidos_en_proceso`
--
ALTER TABLE `pedidos_en_proceso`
  ADD PRIMARY KEY (`ID_P`);

--
-- Indices de la tabla `pedidos_en_proceso2`
--
ALTER TABLE `pedidos_en_proceso2`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `pedidos_x_surtir`
--
ALTER TABLE `pedidos_x_surtir`
  ADD PRIMARY KEY (`ID_Pedido`);

--
-- Indices de la tabla `pedidos_x_surtir2`
--
ALTER TABLE `pedidos_x_surtir2`
  ADD PRIMARY KEY (`ID_P`);

--
-- Indices de la tabla `programaciones`
--
ALTER TABLE `programaciones`
  ADD PRIMARY KEY (`ID_P`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `pedidos_en_proceso`
--
ALTER TABLE `pedidos_en_proceso`
  MODIFY `ID_P` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `pedidos_en_proceso2`
--
ALTER TABLE `pedidos_en_proceso2`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `pedidos_x_surtir`
--
ALTER TABLE `pedidos_x_surtir`
  MODIFY `ID_Pedido` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `pedidos_x_surtir2`
--
ALTER TABLE `pedidos_x_surtir2`
  MODIFY `ID_P` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `programaciones`
--
ALTER TABLE `programaciones`
  MODIFY `ID_P` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
