<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>Registro | Constructora</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Favicons -->
    <link href="./assets/img/favicon.png" rel="icon">
    <link href="./assets/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.gstatic.com" rel="preconnect">
    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
        rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="./assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="./assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="./assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="./assets/vendor/quill/quill.snow.css" rel="stylesheet">
    <link href="./assets/vendor/quill/quill.bubble.css" rel="stylesheet">
    <link href="./assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="./assets/vendor/simple-datatables/style.css" rel="stylesheet">

    <!-- Template Main CSS File -->
    <link href="./assets/css/style.css" rel="stylesheet">
</head>

<body>

    <main>
        <div class="container">

            <section
                class="section register min-vh-100 d-flex flex-column align-items-center justify-content-center py-4">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg col-md-6 d-flex flex-column align-items-center justify-content-center">

                            <div class="d-flex justify-content-center py-4">
                                <a href="./Register-Users" class="logo d-flex align-items-center w-auto">
                                    <img src="./assets/img/logo.png" width="50" height="350">
                                </a>
                            </div><!-- End Logo -->

                            <!-- Estructura de Registro-->
                            <div class="card">
                                <div class="card-body">
                                    <div class="pt-4 pb-2">
                                        <h5 class="card-title text-center pb-0 fs-4">Creación de Cuenta</h5>
                                        <p class="text-center small">Ingresa todos los campos solicitados</p>
                                    </div>

                                    <form class="row needs-validation" novalidate method="POST" action="./Actions-Users/" enctype="multipart/form-data">
                                        <div class="col-md-3">
                                            <label class="form-label">Tipo</label>
                                            <select class="form-select" id="tipo" name="tipo" required>
                                                <option selected disabled value="">Selecciona...</option>
                                                <option value="Moral">Moral</option>
                                                <option value="Fisica">Fisica</option>
                                            </select>
                                            <div class="invalid-feedback"></div>
                                        </div>
                
                                        <div class="col-md-4">
                                            <label class="form-label">RFC</label>
                                            <input type="text" class="form-control" placeholder="Ingresa tu RFC" name="rfc" required oninput="validarRFC(this)">
                                            <div class="valid-feedback"></div>
                                            <div class="invalid-feedback"></div>
                                        </div>
                
                                        <div class="col-md-4">
                                            <label class="form-label">CURP</label>
                                            <input type="text" class="form-control" placeholder="Ingresa tu Curp" name="curp" oninput="validarCURP(this)" required>
                                            <div class="valid-feedback"></div>
                                            <div class="invalid-feedback"></div>
                                        </div>
                
                                        <div class="row g-2 col-md-12">
                                            <label class="col-sm-2 col-form-label">Razon Social</label>
                                            <div class="col-sm-10">
                                                <input class="form-control" type="file" id="razon_social" name="razon_social" accept=".pdf" required oninput="validarArchivo(this)">
                                                <div class="invalid-feedback">Selecciona un archivo .PDF</div>
                                                <div class="valid-feedback"></div>
                                            </div>
                                        </div>
                
                                        <div class="col-md-4 position-relative g-2">
                                            <label class="form-label">Tipo de Proveedor</label>
                                            <select class="form-select" name="proveedor" id="proveedor" required>
                                                <option selected disabled value="">Selecciona...</option>
                                                <option value="Bienes">Bienes</option>
                                                <option value="Servicios">Servicios</option>
                                            </select>
                                            <div class="invalid-feedback"></div>
                                        </div>
                
                                        <div class="col-md-4 position-relative g-2">
                                            <label class="form-label">Opciones de Bienes</label>
                                            <select class="form-select" name="valor_bienes" id="valor_bienes" disabled>
                                                <option selected disabled value="">Selecciona...</option>
                                                <option value="Aceros">Aceros</option>
                                                <option value="Aditivos">Aditivos</option>
                                                <option value="Agregados">Agregados</option>
                                                <option value="Canceleria">Cancelería</option>
                                                <option value="Carpinteria">Carpintería</option>
                                                <option value="Cimbras">Cimbras</option>
                                                <option value="Combustibles">Combustible</option>
                                                <option value="Electrico">Electrico</option>
                                                <option value="Ferreteria">Ferretería</option>
                                                <option value="Jardineria">Jardinería</option>
                                                <option value="Muebles">Muebles</option>
                                                <option value="Piedras">Piedras</option>
                                                <option value="Pinturas">Pinturas</option>
                                                <option value="Azulejos">Azulejos</option>
                                                <option value="Plasticos">Plásticos</option>
                                                <option value="Plomeria">Plomería</option>
                                                <option value="Polvos">Polvos</option>
                                                <option value="Prefabricados">Prefabricados</option>
                                            </select>
                                        </div>
                                        <div class="col-md-4 position-relative g-2">
                                            <label class="form-label">Opciones de Servicios</label>
                                            <select class="form-select" name="valor_servicios" id="valor_servicios" disabled>
                                                <option selected disabled value="">Selecciona...</option>
                                                <option value="Agua Potable">Agua Potable</option>
                                                <option value="Capacitacion personal">Capacitación al Personal</option>
                                                <option value="Energia electrica">Energía eléctrica</option>
                                                <option value="Finanzas">Finanzas</option>
                                                <option value="Fletes y mudanzas">Fletes y mudanzas</option>
                                                <option value="Herramientas">Herramientas</option>
                                                <option value="Internet">Internet</option>
                                                <option value="Instalaciones provicionales">Instalaciones provicionales</option>
                                                <option value="Maquinaria y equipo">Maquinaría y equipo</option>
                                                <option value="Papeleria">Papelería</option>
                                                <option value="Proteccion y seguridad">Protección y seguridad</option>
                                                <option value="Recoleccion basura">Recoleccion de basura</option>
                                                <option value="Reparacion y mantenimiento">Reparación y mantenimiento</option>
                                                <option value="Seguridad">Seguridad</option>
                                                <option value="Salud e higiene">Salud e higiene</option>
                                                <option value="Telefonía">Telefonía móvil</option>
                                                <option value="Subcontratos">Subcontratos</option>
                                            </select>
                                        </div>
                
                                        <div class="row g-2 col-md-12">
                                            <label class="col-sm-2 col-form-label">Constancia Fiscal</label>
                                            <div class="col-sm-10">
                                                <input class="form-control" type="file" id="constancia_fiscal" name="constancia_fiscal" accept=".pdf" required oninput="validarArchivo(this)">
                                                <div class="invalid-feedback">Selecciona un archivo .PDF</div>
                                                <div class="valid-feedback"></div>
                                            </div>
                                        </div>
                
                                        <div class="row g-2 col-md-12">
                                            <label class="col-sm-2 col-form-label">O. Cumplimiento</label>
                                            <div class="col-sm-10">
                                                <input class="form-control" type="file" id="cumplimiento" name="cumplimiento" accept=".pdf" required oninput="validarArchivo(this)">
                                                <div class="invalid-feedback">Selecciona un archivo .PDF</div>
                                                <div class="valid-feedback"></div>
                                            </div>
                                        </div>
                
                                        <div class="row g-2 col-md-12">
                                            <label class="col-sm-2 col-form-label">Cta Bancaria</label>
                                            <div class="col-sm-10">
                                                <input class="form-control" type="file" id="cta_bancaria" name="cta_bancaria" accept=".pdf" required oninput="validarArchivo(this)">
                                                <div class="invalid-feedback" id="error-message">Selecciona un archivo .PDF</div>
                                                <div class="valid-feedback" id="error-message"></div>
                                            </div>
                                        </div>
                
                                        <div class="col-md-12 g-3">
                                            <label class="form-label">Direccion</label>
                                            <input type="text" class="form-control" required placeholder="Ingresa tu Direccion" name="direccion" required>
                                            <div class="invalid-feedback"></div>
                                        </div>
                                        
                                        <div class="row g-2">
                                            <div class="col-auto">
                                                <label class="col-form-label">Contacto Vitas</label>
                                            </div>
                                            <div class="col">
                                                <input type="text" class="form-control" placeholder="Nombre Completo" name="contacto_vitas_nombre" required oninput="validarNombre(this)">
                                                <div class="invalid-feedback"></div>
                                            </div>
                                            <div class="col">
                                                <input type="email" class="form-control" placeholder="Correo" name="contacto_vitas_correo" required oninput="validarCorreo(this)">
                                                <div class="invalid-feedback"></div>
                                                <div class="valid-feedback"></div>
                                            </div>
                                            <div class="col">
                                                <input type="text" class="form-control" placeholder="Telefono" name="contacto_vitas_telefono" required oninput="validarTelefono(this)">
                                                <div class="invalid-feedback"></div>
                                                <div class="valid-feedback"></div>
                                            </div>
                                            <div class="col">
                                                <input type="text" class="form-control" placeholder="Celular" name="contacto_vitas_celular" required oninput="validarCelular(this)">
                                                <div class="invalid-feedback"></div>
                                                <div class="valid-feedback"></div>
                                            </div>
                                        </div>
                
                                        <div class="row g-2">
                                            <div class="col-auto">
                                                <label class="col-form-label">Contacto Conta</label>
                                            </div>
                                            <div class="col">
                                                <input type="text" class="form-control" placeholder="Nombre Completo" name="contacto_conta_nombre" required oninput="validarNombre(this)">
                                                <div class="valid-feedback"></div>
                                                <div class="invalid-feedback"></div>
                                            </div>
                                            <div class="col">
                                                <input type="email" class="form-control" placeholder="Correo" name="contacto_conta_correo" required oninput="validarCorreo(this)">
                                                <div class="invalid-feedback"></div>
                                                <div class="valid-feedback"></div>
                                            </div>
                                            <div class="col">
                                                <input type="text" class="form-control" placeholder="Telefono" name="contacto_conta_telefono" required oninput="validarTelefono(this)">
                                                <div class="invalid-feedback"></div>
                                                <div class="valid-feedback"></div>
                                            </div>
                                            <div class="col">
                                                <input type="text" class="form-control" placeholder="Celular" name="contacto_conta_celular" required oninput="validarCelular(this)">
                                                <div class="invalid-feedback"></div>
                                                <div class="valid-feedback"></div>
                                            </div>
                                        </div>
                
                                        <div class="row g-2">
                                            <div class="col-auto">
                                                <label class="col-form-label">Contacto C y C</label>
                                            </div>
                                            <div class="col">
                                                <input type="text" class="form-control" placeholder="Nombre Completo" name="contacto_cyc_nombre" required oninput="validarNombre(this)">
                                                <div class="invalid-feedback"></div>
                                            </div>
                                            <div class="col">
                                                <input type="email" class="form-control" placeholder="Correo" name="contacto_cyc_correo" required oninput="validarCorreo(this)">
                                                <div class="invalid-feedback"></div>
                                                <div class="valid-feedback"></div>
                                            </div>
                                            <div class="col">
                                                <input type="text" class="form-control" placeholder="Telefono" name="contacto_cyc_telefono" required oninput="validarTelefono(this)">
                                                <div class="invalid-feedback"></div>
                                                <div class="valid-feedback"></div>
                                            </div>
                                            <div class="col">
                                                <input type="text" class="form-control" placeholder="Celular" name="contacto_cyc_celular" required oninput="validarCelular(this)">
                                                <div class="invalid-feedback"></div>
                                                <div class="valid-feedback"></div>
                                            </div>
                                        </div>
                
                                        <div class="row g-2">
                                            <div class="col-auto">
                                                <label class="col"> Dias de Credito</label>
                                            </div>
                                            <div class="col">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio" name="dias_credito" value="Contado" id="contado">
                                                    <label class="form-check-label" for="contado">Contado</label>
                                                </div>
                                            </div>
                                            <div class="col">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio" name="dias_credito" value="8 Días" id="8_dias">
                                                    <label class="form-check-label" for="8_dias">8 Días</label>
                                                </div>
                                            </div>
                                            <div class="col">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio" name="dias_credito" value="15 Días" id="15_dias">
                                                    <label class="form-check-label" for="15_dias">15 Días</label>
                                                </div>
                                            </div>
                                            <div class="col">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio" name="dias_credito" value="30 Días" id="30_dias">
                                                    <label class="form-check-label" for="30_dias">30 Días</label>
                                                </div>
                                            </div> 	
                                        </div>
                
                                        <div class="col-4 g-3">
                                            <label class="form-label">Contraseña</label>
                                            <input type="password" name="password" class="form-control" id="yourPassword" required>
                                            <div class="invalid-feedback"></div>
                                            <div class="form-check form-switch">
                                                <input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault">
                                                <label class="form-check-label" for="flexSwitchCheckDefault">Mostrar constraseña</label>
                                            </div>
                                            <script>
                                                //Declaracion de los DOM's
                                                    let showPass = document.getElementById("flexSwitchCheckDefault"); //DOM del checkBox para mostrar contraseña.
                                                    let inputPass = document.getElementById("yourPassword"); //DOM para el input de la contraseña.
                
                                                    //Funcion para mostrar contraseña en la interfaz
                                                    function mostrarContrasena() {
                
                                                        showPass.addEventListener("change", (e) => {//Escuchar evento de cuando se active el checkBox
                                                            if (showPass.checked) { //Si el estado del checkBox es activo.
                                                                inputPass.type = "text"; //Cambiara el tipo del input a un "text" para que muestre los caracteres.
                                                            } else {
                                                                inputPass.type = "password"; //En cambio si esto no es asi, se colocara el type del input en "Password" para ocultar los caracteres.
                                                            }
                                                        });
                                                    }
                                                    mostrarContrasena(); //Mandar a llamar la funcion para si ejecucion.
                                            </script>
                                        </div>
                
                                        <div class="col-12 g-3">
                                            <center><button class="btn btn-primary" type="submit">Registrarme</button></center>
                                        </div>

                                        <div class="col-12">
                                            <p class="small mb-0">Tienes Cuenta? <a href="./Login">Inicio Sesión</a></p>
                                        </div>
                                    </form>

                                </div>
                            </div>
                            <!-- End Estructura de Registro-->
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </main><!-- End #main -->

    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

    <!-- Vendor JS Files -->
    <script src="./assets/vendor/apexcharts/apexcharts.min.js"></script>
    <script src="./assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="./assets/vendor/chart.js/chart.umd.js"></script>
    <script src="./assets/vendor/echarts/echarts.min.js"></script>
    <script src="./assets/vendor/quill/quill.min.js"></script>
    <script src="./assets/vendor/simple-datatables/simple-datatables.js"></script>
    <script src="./assets/vendor/tinymce/tinymce.min.js"></script>
    <script src="./assets/vendor/php-email-form/validate.js"></script>

    <!-- Template Main JS File -->
    <script src="./assets/js/main.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="./assets/js/validaciones_form.js"></script>

</body>

</html>