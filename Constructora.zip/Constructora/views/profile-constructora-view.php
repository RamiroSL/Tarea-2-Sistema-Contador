<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>Perfil</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Favicons -->
    <link href="./assets/img/favicon.png" rel="icon">
    <link href="./assets/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.gstatic.com" rel="preconnect">
    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
        rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="./assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="./assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="./assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="./assets/vendor/quill/quill.snow.css" rel="stylesheet">
    <link href="./assets/vendor/quill/quill.bubble.css" rel="stylesheet">
    <link href="./assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="./assets/vendor/simple-datatables/style.css" rel="stylesheet">

    <!-- Template Main CSS File -->
    <link href="./assets/css/style.css" rel="stylesheet">
</head>

<body>

    <!-- ======= Header ======= -->
    <header id="header" class="header fixed-top d-flex align-items-center">

        <div class="d-flex align-items-center justify-content-between">
            <a href="./Home/" class="logo d-flex align-items-center">
                <img src="./assets/img/logo.png" alt="">
                <span class="d-none d-lg-block">Constructora</span>
            </a>
            <i class="bi bi-list toggle-sidebar-btn"></i>
        </div><!-- End Logo -->

        <nav class="header-nav ms-auto">
            <ul class="d-flex align-items-center">

                <li class="nav-item dropdown pe-3">

                    <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
                        <i class="ri-account-circle-fill" style="font-size: 25px;"></i>
                        <span class="d-none d-md-block dropdown-toggle ps-2">Bienvenido, <?php echo $_SESSION['rfc'];?></span>
                    </a><!-- End Profile Iamge Icon -->

                    <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
                        <li class="dropdown-header">
                            <h6><?php echo $_SESSION['rfc'];?></h6>
                        </li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>

                        <li>
                            <a class="dropdown-item d-flex align-items-center" href="./Profile">
                                <i class="bi bi-person"></i>
                                <span>Mi Perfil</span>
                            </a>
                        </li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>

                        <li>
                            <a class="dropdown-item d-flex align-items-center" href="./Logout">
                                <i class="bi bi-box-arrow-right"></i>
                                <span>Cerrar Sesion</span>
                            </a>
                        </li>

                    </ul><!-- End Profile Dropdown Items -->
                </li><!-- End Profile Nav -->

            </ul>
        </nav><!-- End Icons Navigation -->

    </header><!-- End Header -->

    <!-- ======= Sidebar ======= -->
    <aside id="sidebar" class="sidebar">
        <ul class="sidebar-nav" id="sidebar-nav">
    
            <li class="nav-item">
                <a class="nav-link " href="./Home/">
                    <i class="bi bi-grid"></i>
                    <span>Inicio</span>
                </a>
            </li><!-- End Dashboard Nav -->
    
            <li class="nav-heading">Acciones</li>
    
            <li class="nav-item">
                <a class="nav-link collapsed" href="./Pedidos_Surtir">
                    <i class="bi bi-truck"></i>
                    <span>Pedidos x Surtir</span>
                </a>
            </li><!-- End Pedidos x Surtir Page Nav -->
    
            <li class="nav-item">
                <a class="nav-link collapsed" href="./Pedidos_Proceso">
                    <i class="bi bi-box-seam"></i>
                    <span>Pedidos en Proceso</span>
                </a>
            </li><!-- End Pedidos en Proceso Page Nav -->
    
            <li class="nav-item">
                <a class="nav-link collapsed" href="./Programaciones">
                    <i class="bi bi-alarm"></i>
                    <span>Programaciones</span>
                </a>
            </li><!-- End Programaciones Page Nav -->
        </ul>
    </aside><!-- End Sidebar-->

    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Perfil</h1>
        </div><!-- End Page Title -->

        <section class="section profile">

            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Informacion del Usuario, <?php echo $Datos['rfc']?></h5>
                    <!-- Form del Perfil -->
                    <form class="row needs-validation" novalidate action="./Update-Profile/" method="post" enctype="multipart/form-data">
                        <div class="col-md-3">
                            <label class="form-label">Tipo</label>
                            <select class="form-select" id="tipo" name="tipo" required>
                                <option selected disabled value="">Selecciona...</option>
                                <option value="Moral" <?php if ($Datos['tipo'] === 'Moral') echo 'selected'; ?>>Moral</option>
                                <option value="Fisica" <?php if ($Datos['tipo'] === 'Fisica') echo 'selected'; ?>>Fisica</option>
                            </select>
                            <div class="invalid-feedback"></div>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">RFC</label>
                            <input type="text" class="form-control" placeholder="Ingresa tu RFC" name="rfc" required oninput="validarRFC(this)" value="<?php echo $Datos['rfc'];?>">
                            <div class="valid-feedback"></div>
                            <div class="invalid-feedback"></div>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">CURP</label>
                            <input type="text" class="form-control" placeholder="Ingresa tu Curp" name="curp" oninput="validarCURP(this)" required value="<?php echo $Datos['curp'];?>">
                            <div class="valid-feedback"></div>
                            <div class="invalid-feedback"></div>
                        </div>

                        <div class="row g-2 col-md-12">
                            <label class="col-sm-2 col-form-label">Razon Social</label>
                            <div class="col-sm-10">
                                <div class="input-group">
                                    <input class="form-control" type="file" id="razon_social" name="razon_social" accept=".pdf" required  oninput="validarArchivo(this)">
                                    <button class="btn btn-outline-secondary" type="button" id="mostrarPdfBoton" data-toggle="modal" data-target="#pdfModal">Pdf de la Base</button>
                                </div>
                                <div class="invalid-feedback">Selecciona un archivo .PDF</div>
                                <div class="valid-feedback"></div>
                            </div>
                        </div>

                        <!-- Modal -->
                        <div class="modal fade" id="pdfModal" tabindex="-1" role="dialog" aria-labelledby="pdfModalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="pdfModalLabel">Vista del Pdf Guardado en la Base de Datos</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <iframe id="pdfIframe" width="100%" height="350"></iframe>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-danger rounded-pill" data-dismiss="modal">Cerrar</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Fin del modal -->
                        
                        <div class="col-md-4 position-relative g-2">
                            <label class="form-label">Tipo de Proveedor</label>
                            <select class="form-select" name="proveedor" id="proveedor" required>
                                <option selected disabled value="">Selecciona...</option>
                                <option value="Bienes" <?php if ($Datos['proveedor'] === 'Bienes') echo 'selected'; ?>>Bienes</option>
								<option value="Servicios" <?php if ($Datos['proveedor'] === 'Servicios') echo 'selected'; ?>>Servicios</option>
                            </select>
                            <div class="invalid-feedback"></div>
                        </div>

                        <div class="col-md-4 position-relative g-2">
                            <label class="form-label">Opciones de Bienes</label>
                            <select class="form-select" name="valor_bienes" id="valor_bienes" <?php if ($Datos['proveedor'] !== 'Bienes') echo 'disabled'; ?>>
                                <option selected disabled value="">Selecciona...</option>
                                <option value="Aceros">Aceros</option>
                                <option value="Aditivos">Aditivos</option>
                                <option value="Agregados">Agregados</option>
                                <option value="Canceleria">Cancelería</option>
                                <option value="Carpinteria">Carpintería</option>
                                <option value="Cimbras">Cimbras</option>
                                <option value="Combustibles">Combustible</option>
                                <option value="Electrico">Electrico</option>
                                <option value="Ferreteria">Ferretería</option>
                                <option value="Jardineria">Jardinería</option>
                                <option value="Muebles">Muebles</option>
                                <option value="Piedras">Piedras</option>
                                <option value="Pinturas">Pinturas</option>
                                <option value="Azulejos">Azulejos</option>
                                <option value="Plasticos">Plásticos</option>
                                <option value="Plomeria">Plomería</option>
                                <option value="Polvos">Polvos</option>
                                <option value="Prefabricados">Prefabricados</option>
                            </select>
                        </div>
                        <div class="col-md-4 position-relative g-2">
                            <label class="form-label">Opciones de Servicios</label>
                            <select class="form-select" name="valor_servicios" id="valor_servicios" <?php if ($Datos['proveedor'] !== 'Servicios') echo 'disabled'; ?>>
                                <option selected disabled value="">Selecciona...</option>
                                <option value="Agua Potable">Agua Potable</option>
                                <option value="Capacitacion personal">Capacitación al Personal</option>
                                <option value="Energia electrica">Energía eléctrica</option>
                                <option value="Finanzas">Finanzas</option>
                                <option value="Fletes y mudanzas">Fletes y mudanzas</option>
                                <option value="Herramientas">Herramientas</option>
                                <option value="Internet">Internet</option>
                                <option value="Instalaciones provicionales">Instalaciones provicionales</option>
                                <option value="Maquinaria y equipo">Maquinaría y equipo</option>
                                <option value="Papeleria">Papelería</option>
                                <option value="Proteccion y seguridad">Protección y seguridad</option>
                                <option value="Recoleccion basura">Recoleccion de basura</option>
                                <option value="Reparacion y mantenimiento">Reparación y mantenimiento</option>
                                <option value="Seguridad">Seguridad</option>
                                <option value="Salud e higiene">Salud e higiene</option>
                                <option value="Telefonía">Telefonía móvil</option>
                                <option value="Subcontratos">Subcontratos</option>
                            </select>
                        </div>

                        <div class="row g-2 col-md-12">
                            <label class="col-sm-2 col-form-label">Constancia Fiscal</label>
                            <div class="col-sm-10">
                                <div class="input-group">
                                    <input class="form-control" type="file" id="constancia_fiscal" name="constancia_fiscal" accept=".pdf" required oninput="validarArchivo(this)">
                                    <button class="btn btn-outline-secondary" type="button" id="mostrarPdfBoton1" data-toggle="modal" data-target="#pdfModal">Pdf de la Base</button>
                                </div>
                                <div class="invalid-feedback">Selecciona un archivo .PDF</div>
                                <div class="valid-feedback"></div>
                            </div>
                        </div>

                        <div class="row g-2 col-md-12">
                            <label class="col-sm-2 col-form-label">O. Cumplimiento</label>
                            <div class="col-sm-10">
                                <div class="input-group">
                                    <input class="form-control" type="file" id="cumplimiento" name="cumplimiento" accept=".pdf" required oninput="validarArchivo(this)">
                                    <button class="btn btn-outline-secondary" type="button" id="mostrarPdfBoton2" data-toggle="modal" data-target="#pdfModal">Pdf de la Base</button>
                                </div>
                                <div class="invalid-feedback">Selecciona un archivo .PDF</div>
                                <div class="valid-feedback"></div>
                            </div>
                        </div>

                        <div class="row g-2 col-md-12">
                            <label class="col-sm-2 col-form-label">Cta Bancaria</label>
                            <div class="col-sm-10">
                                <div class="input-group">
                                    <input class="form-control" type="file" id="cta_bancaria" name="cta_bancaria" accept=".pdf" required oninput="validarArchivo(this)">
                                    <button class="btn btn-outline-secondary" type="button" id="mostrarPdfBoton3" data-toggle="modal" data-target="#pdfModal">Pdf de la Base</button>
                                </div>
                                <div class="invalid-feedback" id="error-message">Selecciona un archivo .PDF</div>
                                <div class="valid-feedback" id="error-message"></div>
                            </div>
                        </div>

                        <script>
                            document.getElementById("mostrarPdfBoton").addEventListener("click", function () {
                                // Obtén la ruta o el nombre del archivo PDF del usuario desde PHP
                                var rutaArchivo = "<?php echo $Datos['razon_social']; ?>"; // Asegúrate de que esta variable contenga la ruta correcta al PDF
                                // Actualiza el iframe en el modal para mostrar el PDF
                                var pdfIframe = document.getElementById("pdfIframe");
                                pdfIframe.src = "./uploads/" + rutaArchivo; // Reemplaza con la ruta correcta a la carpeta de archivos PDF en tu servidor
                            });


                            document.getElementById("mostrarPdfBoton1").addEventListener("click", function () {
                                // Obtén la ruta o el nombre del archivo PDF del usuario desde PHP
                                var rutaArchivo1 = "<?php echo $Datos['constancia_fiscal']?>"; // Asegúrate de que esta variable contenga la ruta correcta al PDF
                                // Actualiza el iframe en el modal para mostrar el PDF
                                var pdfIframe = document.getElementById("pdfIframe");
                                pdfIframe.src = "./uploads/" + rutaArchivo1; // Reemplaza con la ruta correcta a la carpeta de archivos PDF en tu servidor
                            });


                            document.getElementById("mostrarPdfBoton2").addEventListener("click", function () {
                                // Obtén la ruta o el nombre del archivo PDF del usuario desde PHP
                                var rutaArchivo2 = "<?php echo $Datos['cumplimiento']; ?>"; // Asegúrate de que esta variable contenga la ruta correcta al PDF
                                // Actualiza el iframe en el modal para mostrar el PDF
                                var pdfIframe = document.getElementById("pdfIframe");
                                pdfIframe.src = "./uploads/" + rutaArchivo2; // Reemplaza con la ruta correcta a la carpeta de archivos PDF en tu servidor
                            });


                            document.getElementById("mostrarPdfBoton3").addEventListener("click", function () {
                                // Obtén la ruta o el nombre del archivo PDF del usuario desde PHP
                                var rutaArchivo3 = "<?php echo $Datos['cta_bancaria']; ?>"; // Asegúrate de que esta variable contenga la ruta correcta al PDF
                                // Actualiza el iframe en el modal para mostrar el PDF
                                var pdfIframe = document.getElementById("pdfIframe");
                                pdfIframe.src = "./uploads/" + rutaArchivo3; // Reemplaza con la ruta correcta a la carpeta de archivos PDF en tu servidor
                            });
                        </script>

                        <div class="col-md-12 g-3">
                            <label class="form-label">Direccion</label>
                            <input type="text" class="form-control" required placeholder="Ingresa tu Direccion" name="direccion" required value="<?php echo $Datos['direccion'];?>">
                            <div class="invalid-feedback"></div>
                        </div>
                        
                        <div class="row g-2">
                            <div class="col-auto">
                                <label class="col-form-label">Contacto Vitas</label>
                            </div>
                            <div class="col">
                                <input type="text" class="form-control" placeholder="Nombre Completo" name="contacto_vitas_nombre" required oninput="validarNombre(this)" value="<?php echo $Datos['contacto_vitas_nombre'];?>">
                                <div class="invalid-feedback"></div>
                            </div>
                            <div class="col">
                                <input type="email" class="form-control" placeholder="Correo" name="contacto_vitas_correo" required oninput="validarCorreo(this)" value="<?php echo $Datos['contacto_vitas_correo'];?>">
                                <div class="invalid-feedback"></div>
                                <div class="valid-feedback"></div>
                            </div>
                            <div class="col">
                                <input type="text" class="form-control" placeholder="Telefono" name="contacto_vitas_telefono" required oninput="validarTelefono(this)" value="<?php echo $Datos['contacto_vitas_telefono'];?>">
                                <div class="invalid-feedback"></div>
                                <div class="valid-feedback"></div>
                            </div>
                            <div class="col">
                                <input type="text" class="form-control" placeholder="Celular" name="contacto_vitas_celular" required oninput="validarCelular(this)" value="<?php echo $Datos['contacto_vitas_celular'];?>">
                                <div class="invalid-feedback"></div>
                                <div class="valid-feedback"></div>
                            </div>
                        </div>

                        <div class="row g-2">
                            <div class="col-auto">
                                <label class="col-form-label">Contacto Conta</label>
                            </div>
                            <div class="col">
                                <input type="text" class="form-control" placeholder="Nombre Completo" name="contacto_conta_nombre" required oninput="validarNombre(this)" value="<?php echo $Datos['contacto_conta_nombre'];?>">
                                <div class="valid-feedback"></div>
                                <div class="invalid-feedback"></div>
                            </div>
                            <div class="col">
                                <input type="email" class="form-control" placeholder="Correo" name="contacto_conta_correo" required oninput="validarCorreo(this)" value="<?php echo $Datos['contacto_conta_correo'];?>">
                                <div class="invalid-feedback"></div>
                                <div class="valid-feedback"></div>
                            </div>
                            <div class="col">
                                <input type="text" class="form-control" placeholder="Telefono" name="contacto_conta_telefono" required oninput="validarTelefono(this)" value="<?php echo $Datos['contacto_conta_telefono'];?>">
                                <div class="invalid-feedback"></div>
                                <div class="valid-feedback"></div>
                            </div>
                            <div class="col">
                                <input type="text" class="form-control" placeholder="Celular" name="contacto_conta_celular" required oninput="validarCelular(this)" value="<?php echo $Datos['contacto_conta_celular'];?>">
                                <div class="invalid-feedback"></div>
                                <div class="valid-feedback"></div>
                            </div>
                        </div>

                        <div class="row g-2">
                            <div class="col-auto">
                                <label class="col-form-label">Contacto C y C</label>
                            </div>
                            <div class="col">
                                <input type="text" class="form-control" placeholder="Nombre Completo" name="contacto_cyc_nombre" required oninput="validarNombre(this)" value="<?php echo $Datos['contacto_cyc_nombre'];?>">
                                <div class="invalid-feedback"></div>
                            </div>
                            <div class="col">
                                <input type="email" class="form-control" placeholder="Correo" name="contacto_cyc_correo" required oninput="validarCorreo(this)" value="<?php echo $Datos['contacto_cyc_correo'];?>">
                                <div class="invalid-feedback"></div>
                                <div class="valid-feedback"></div>
                            </div>
                            <div class="col">
                                <input type="text" class="form-control" placeholder="Telefono" name="contacto_cyc_telefono" required oninput="validarTelefono(this)" value="<?php echo $Datos['contacto_cyc_telefono'];?>">
                                <div class="invalid-feedback"></div>
                                <div class="valid-feedback"></div>
                            </div>
                            <div class="col">
                                <input type="text" class="form-control" placeholder="Celular" name="contacto_cyc_celular" required oninput="validarCelular(this)" value="<?php echo $Datos['contacto_cyc_celular'];?>">
                                <div class="invalid-feedback"></div>
                                <div class="valid-feedback"></div>
                            </div>
                        </div>

                        <div class="row g-2">
                            <div class="col-auto">
                                <label class="col"> Dias de Credito</label>
                            </div>
                            <div class="col">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="dias_credito" value="Contado" id="contado" <?php if ($Datos && $Datos['dias_credito'] === 'Contado') echo 'checked'; ?>>
                                    <label class="form-check-label" for="contado">Contado</label>
                                </div>
                            </div>
                            <div class="col">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="dias_credito" value="8 Días" id="8_dias" <?php if ($Datos && $Datos['dias_credito'] === '8 Días') echo 'checked'; ?>>
                                    <label class="form-check-label" for="8_dias">8 Días</label>
                                </div>
                            </div>
                            <div class="col">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="dias_credito" value="15 Días" id="15_dias" <?php if ($Datos && $Datos['dias_credito'] === '15 Días') echo 'checked'; ?>>
                                    <label class="form-check-label" for="15_dias">15 Días</label>
                                </div>
                            </div>
                            <div class="col">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="dias_credito" value="30 Días" id="30_dias" <?php if ($Datos && $Datos['dias_credito'] === '30 Días') echo 'checked'; ?>>
                                    <label class="form-check-label" for="30_dias">30 Días</label>
                                </div>
                            </div> 	
                        </div>

                        <div class="col-4 g-3">
                            <label class="form-label">Contraseña</label>
                            <input type="password" name="password" class="form-control" id="yourPassword" required value="<?php echo $Datos['password'];?>">
                            <div class="invalid-feedback"></div>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault">
                                <label class="form-check-label" for="flexSwitchCheckDefault">Mostrar constraseña</label>
                            </div>
                            <script>
                                //Declaracion de los DOM's
                                    let showPass = document.getElementById("flexSwitchCheckDefault"); //DOM del checkBox para mostrar contraseña.
                                    let inputPass = document.getElementById("yourPassword"); //DOM para el input de la contraseña.

                                    //Funcion para mostrar contraseña en la interfaz
                                    function mostrarContrasena() {

                                        showPass.addEventListener("change", (e) => {//Escuchar evento de cuando se active el checkBox
                                            if (showPass.checked) { //Si el estado del checkBox es activo.
                                                inputPass.type = "text"; //Cambiara el tipo del input a un "text" para que muestre los caracteres.
                                            } else {
                                                inputPass.type = "password"; //En cambio si esto no es asi, se colocara el type del input en "Password" para ocultar los caracteres.
                                            }
                                        });
                                    }
                                    mostrarContrasena(); //Mandar a llamar la funcion para si ejecucion.
                            </script>
                        </div>

                        <div class="col-12 g-3">
                            <center><button class="btn btn-primary" type="submit">Actualizar Perfil</button></center>
                        </div>
                    </form>
                    <!-- End Form del Perfil -->
                </div>
            </div>
        </section>
    </main><!-- End #main -->

    <!-- ======= Footer ======= -->
    <footer id="footer" class="footer">
        <div class="copyright">
            &copy; Copyright <strong><span>Jonathan | Ramiro</span></strong>
        </div>
    </footer>
    <!-- End Footer -->

    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

    <!-- Vendor JS Files -->
    <script src="./assets/vendor/apexcharts/apexcharts.min.js"></script>
    <script src="./assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="./assets/vendor/chart.js/chart.umd.js"></script>
    <script src="./assets/vendor/echarts/echarts.min.js"></script>
    <script src="./assets/vendor/quill/quill.min.js"></script>
    <script src="./assets/vendor/simple-datatables/simple-datatables.js"></script>
    <script src="./assets/vendor/tinymce/tinymce.min.js"></script>
    <script src="./assets/vendor/php-email-form/validate.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    

    <!-- Template Main JS File -->
    <script src="./assets/js/main.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="./assets/js/validaciones_form.js"></script>

</body>

</html>