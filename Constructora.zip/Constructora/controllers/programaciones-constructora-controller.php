<?php
// Inicializar la sesión.
session_start();

include('../models/programaciones-constructora-model.php');

if (isset($_SESSION['rfc'])) {
    try {
        // Crea una instancia del objeto "Contador".
        $ProgramacionesObject = new Programaciones();

        // Obtiene el total de usuarios
        $Programaciones = $ProgramacionesObject->programaciones();

    } catch (\Throwable $th) {
        // En caso de que ocurra un error, redirecciona al usuario a la página de error interno.
        echo "<script>location.href='./views/Error-constructora.php'</script>";
    }

    // Requiere el archivo que contiene la vista "contador-constructora-view.php" para mostrar los resultados obtenidos.
    require('../views/programaciones-constructora-view.php');
} else {
    // Si no existe una sesión activa o el valor de 'email' no está establecido, redirecciona al usuario a la página principal.
    echo "<script>location.href='./Login'</script>";
}