<?php
// Inicializar la sesión.
session_start();

include('../models/pedidos_x_surtir-constructora-model.php');

if (isset($_SESSION['rfc'])) {
    try {
        // Crea una instancia del objeto "Contador".
        $Pedidos_SurtirObject = new Pedidos_x_Surtir();

        // Obtiene el total de usuarios
        $Pedidos_x_Surtir = $Pedidos_SurtirObject->pedidos_Surtir();

        $Pedidos_x_Surtir2 = $Pedidos_SurtirObject->pedidos_Surtir2();

    } catch (\Throwable $th) {
        // En caso de que ocurra un error, redirecciona al usuario a la página de error interno.
        echo "<script>location.href='./views/Error-constructora.php'</script>";
    }

    // Requiere el archivo que contiene la vista "contador-constructora-view.php" para mostrar los resultados obtenidos.
    require('../views/pedidos_x_surtir-constructora-view.php');
} else {
    // Si no existe una sesión activa o el valor de 'email' no está establecido, redirecciona al usuario a la página principal.
    echo "<script>location.href='./Login'</script>";
}