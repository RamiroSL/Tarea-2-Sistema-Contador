<?php
// Inicializar la sesión.
session_start();

include('../models/pedidos_en_proceso-constructora-model.php');

if (isset($_SESSION['rfc'])) {
    try {
        // Crea una instancia del objeto "Contador".
        $PedidosObject = new Pedidos_en_Proceso();

        // Obtiene el total de usuarios
        $Pedidos_Proceso_1 = $PedidosObject->pedidos_en_Proceso();

        $Pedidos_Proceso_2 = $PedidosObject->pedidos_en_Proceso2();

    } catch (\Throwable $th) {
        // En caso de que ocurra un error, redirecciona al usuario a la página de error interno.
        echo "<script>location.href='./views/Error-constructora.php'</script>";
    }

    // Requiere el archivo que contiene la vista "contador-constructora-view.php" para mostrar los resultados obtenidos.
    require('../views/pedidos_en_proceso-constructora-view.php');
} else {
    // Si no existe una sesión activa o el valor de 'email' no está establecido, redirecciona al usuario a la página principal.
    echo "<script>location.href='./Login'</script>";
}