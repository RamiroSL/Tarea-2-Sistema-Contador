<?php
// Inicializar la sesión.
session_start();

// Inclusión del archivo "model" del login que contiene la definición de la clase "Login" para realizar la validación del inicio de sesión.
require('../models/login-constructora-model.php');

try {
    // Declaración de los campos recibidos desde el "view" del login.
$rfc = $_POST['username']; // Variable que almacena el valor del campo de correo electrónico (email) proporcionado por el usuario en el formulario de inicio de sesión.
$password = $_POST['password'];  // Variable que almacena el valor del campo de contraseña (password) proporcionado por el usuario en el formulario de inicio de sesión.

// Crea una instancia del objeto "Login".
$loginObj = new Login();
// Llama al método "validationUser()" de la clase "Login" para validar el inicio de sesión.
// Se le pasan como argumentos el correo electrónico (email) y la contraseña (password) proporcionados por el usuario.
$acces = $loginObj->verificaUsuarios($rfc, $password);
} catch (\Throwable $th) {
    echo "<script>location.href='./views/Error-constructora.php'</script>";
}