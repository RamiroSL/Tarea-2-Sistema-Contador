<?php
// Inicializar la sesión.
session_start();

include('../models/contador-constructora-model.php');

if (isset($_SESSION['rfc'])) {
    try {
        // Crea una instancia del objeto "Contador".
        $ContadorObject = new Contador();

        // Obtiene el total de usuarios
        $showUser = $ContadorObject->showUser();

    } catch (\Throwable $th) {
        // En caso de que ocurra un error, redirecciona al usuario a la página de error interno.
        echo "<script>location.href='./views/Error-constructora.php'</script>";
    }

    // Requiere el archivo que contiene la vista "contador-constructora-view.php" para mostrar los resultados obtenidos.
    require('../views/contador-constructora-view.php');
} else {
    // Si no existe una sesión activa o el valor de 'email' no está establecido, redirecciona al usuario a la página principal.
    echo "<script>location.href='./Login'</script>";
}