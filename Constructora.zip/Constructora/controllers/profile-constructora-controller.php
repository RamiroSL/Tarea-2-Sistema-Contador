<?php

session_start();

require('../models/profile-constructora-model.php');

// Se valida si existe una sesión activa (usuario autenticado).
if (isset($_SESSION['rfc'])) {
    try {
        $ObjPerfil = new Perfil();

        $Datos = $ObjPerfil->getInformacion($_SESSION['rfc']);

    } catch (\Throwable $th) {
        echo "<script>location.href='./views/Error-constructora.php'</script>";
    }
    
    // Requiere el archivo que contiene la vista para mostrar la información del perfil del usuario.
    require('../views/profile-constructora-view.php');
}else {
    // De lo contrario, si no hay sesión activa (usuario no autenticado), se redireccionará al "Login".
    echo "<script>location.href='./Login'</script>";
}