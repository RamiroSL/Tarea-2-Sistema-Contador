<?php

session_start();

require('../models/registro-constructora-model.php');

// Se valida si existe una sesión activa (usuario autenticado).

try {
    $ObjRegistro = new Registro();


     // Requiere el archivo que contiene la vista para mostrar la información del perfil del usuario.
    require('../views/registro-constructora-view.php');
} catch (\Throwable $th) {
    echo "<script>location.href='./views/Error-constructora.php'</script>";
}